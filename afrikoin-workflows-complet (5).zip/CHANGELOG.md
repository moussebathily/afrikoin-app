# 📜 Journal des modifications (Changelog)

Toutes les modifications notables apportées à AfriKoin seront consignées dans ce fichier.

Le format est basé sur [Keep a Changelog](https://keepachangelog.com/fr/1.0.0/)
et ce projet suit [Semantic Versioning](https://semver.org/lang/fr/).

## [1.2.2] - 2025-08-02
### Ajouté
- Intégration IA visible dans l’interface utilisateur
- Suggestions IA avant publication (titre, image, description, hashtags)
- Génération automatique de miniatures avec prix + logo
- Support QR code vers les annonces
- Ajout du workflow GitHub CI/CD avec tag Git + publication Play Store
- Génération automatique de changelog et release GitHub

## [1.2.1] - 2025-07-27
### Corrigé
- Problème d’icône manquante dans certaines versions Android
- Meilleure gestion des SafeAreaView

## [1.2.0] - 2025-07-20
### Ajouté
- Ajout du mode sombre automatique
- Amélioration du suivi colis avec IA + interface WebView
