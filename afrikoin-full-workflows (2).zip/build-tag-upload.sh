#!/bin/bash

VERSION=$1

if [ -z "$VERSION" ]; then
  echo "Usage: ./build-tag-upload.sh <version>"
  exit 1
fi

# Mise à jour eas.json
sed -i "s/version: .*/version: $VERSION/" eas.json

# Build AAB
eas build --platform android --profile production --non-interactive

# Git tag
git config user.name "GitHub Actions"
git config user.email "actions@github.com"
git tag v$VERSION
git push origin v$VERSION

# Générer changelog
./generate-changelog.sh $VERSION