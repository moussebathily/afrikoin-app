#!/bin/bash

# 💡 Variables
PROFILE="production"
PLATFORM="android"

echo "🚀 Lancement du build EAS ($PROFILE)..."
BUILD_OUTPUT=$(eas build --platform $PLATFORM --profile $PROFILE --non-interactive)

# 🔍 Extraction du lien
BUILD_URL=$(echo "$BUILD_OUTPUT" | grep -Eo "https://expo.dev/accounts/.+/projects/.+/builds/[a-zA-Z0-9]+" | head -n 1)

if [ -n "$BUILD_URL" ]; then
  echo "✅ Build lancé avec succès !"
  echo "🔗 Lien du build : $BUILD_URL"
  echo "🌐 Ouverture dans le navigateur..."
  xdg-open "$BUILD_URL" 2>/dev/null || open "$BUILD_URL"
else
  echo "❌ Aucun lien de build trouvé. Vérifie le résultat de la commande EAS."
  exit 1
fi
