#!/bin/bash
set -e

echo "🔧 Version actuelle : $1"

if [ -z "$1" ]; then
  echo "❌ Veuillez fournir un numéro de version. Exemple : ./build.sh 1.2.2"
  exit 1
fi

VERSION=$1

echo "✅ Mise à jour eas.json"
sed -i "s/\"version\": \".*\"/\"version\": \"$VERSION\"/" eas.json

echo "🚀 Build AAB avec EAS..."
eas build --platform android --profile production --non-interactive

echo "🏷️ Création du tag Git"
git tag v$VERSION
git push origin v$VERSION

echo "🎉 Build terminé pour la version $VERSION"
