#!/bin/bash

# 🚧 Script de build preview pour AfriKoin (.apk)

set -e

VERSION=$1

if [ -z "$VERSION" ]; then
  echo "❌ Version manquante. Utilisation : ./preview.sh 1.2.2-preview"
  exit 1
fi

echo "🧪 Build de test en cours pour la version $VERSION..."

# Vérification fichiers nécessaires
for file in eas.json app.config.js; do
  if [ ! -f "$file" ]; then
    echo "❌ Fichier manquant : $file"
    exit 1
  fi
done

# Mise à jour version dans eas.json
echo "🔧 Mise à jour de eas.json..."
sed -i "" "s/version: .*/version: $VERSION/" eas.json 2>/dev/null || sed -i "s/version: .*/version: $VERSION/" eas.json

# Build APK preview
echo "🏗️ Build APK (preview)..."
eas build --platform android --profile preview --non-interactive

echo "✅ APK de test généré pour la version $VERSION"
