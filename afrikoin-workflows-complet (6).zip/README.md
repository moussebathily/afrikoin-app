# 🌍 AfriKoin

![CI Production](https://github.com/moussebathily/afrikoin-app/actions/workflows/build-deploy.yml/badge.svg)

**AfriKoin** est une plateforme panafricaine de petites annonces assistée par IA.  
Elle permet de publier, rechercher, suivre les colis, générer des images automatiquement et bénéficier d’un assistant intelligent.

---

## 🚀 Fonctionnalités clés

- ✅ Publication d’annonces (photo, vidéo, description IA)
- 🧠 Suggestions IA avant publication (titre, prix, hashtags)
- 🎨 Génération de miniatures stylisées + QR code
- 🌍 Multilingue (auto-traduction des annonces)
- 📦 Suivi colis avec confirmation client
- 🔒 Paiement sécurisé via escrow
- ☁️ Sauvegarde cloud et app mobile

---

## 🛠️ CI/CD Automatisé

Ce dépôt contient un système de **build & déploiement automatisé** vers Google Play :

### 🔧 Workflows GitHub

| Workflow             | Description                                      |
|----------------------|--------------------------------------------------|
| `build-deploy.yml`   | Build .aab, changelog, release, déploiement Play |
| `build-staging.yml`  | Build .apk pour test en interne (preview)        |

---

## 📦 Build local (via EAS)

```bash
# Build production
eas build --platform android --profile production

# Build preview
eas build --platform android --profile preview
```

---

## 🔐 Secrets requis (dans GitHub)

- `EAS_TOKEN` : token d’accès à EAS
- `GOOGLE_PLAY_SERVICE_ACCOUNT` : JSON de service Play Console

---

## 📄 Historique

Voir le [CHANGELOG.md](./CHANGELOG.md) pour toutes les modifications.

---

© 2025 – Mousse Bathily | afrikoin.online
