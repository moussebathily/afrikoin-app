#!/bin/bash

# ✅ Script de publication locale pour AfriKoin

set -e

VERSION=$1

if [ -z "$VERSION" ]; then
  echo "❌ Version manquante. Utilisation : ./publish.sh 1.2.2"
  exit 1
fi

echo "🔧 Construction de la version $VERSION..."

# Vérification des fichiers essentiels
for file in eas.json app.config.js CHANGELOG.md; do
  if [ ! -f "$file" ]; then
    echo "❌ Fichier manquant : $file"
    exit 1
  fi
done

# Build AAB
echo "🏗️ Build avec EAS..."
eas build --platform android --profile production --non-interactive

# Génération changelog
echo "📝 Génération du changelog..."
PREV_TAG=$(git tag --sort=-creatordate | sed -n 1p)
git log $PREV_TAG..HEAD --pretty=format:"- %s" > changelog.txt

# Tag Git
echo "🏷️ Création du tag Git v$VERSION..."
git tag v$VERSION
git push origin v$VERSION

# Commit changelog
echo "💾 Commit du changelog..."
git add changelog.txt
git commit -m "🔖 Changelog pour version $VERSION"
git push

echo "✅ Publication terminée pour la version $VERSION."
