export const lightTheme = {
  background: '#ffffff',
  text: '#000000',
  card: '#f2f2f2',
  primary: '#007AFF'
}

export const darkTheme = {
  background: '#121212',
  text: '#ffffff',
  card: '#1e1e1e',
  primary: '#0A84FF'
}
