#!/bin/bash
echo "🔧 Mise à jour des dépendances..."

npm install
npm audit fix

echo "✅ Fini."
