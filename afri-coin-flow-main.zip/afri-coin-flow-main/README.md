# AfriKoin Flow - African Marketplace Mobile App

## Project Info

**URL**: https://lovable.dev/projects/4ba00307-e1d1-4ec3-9df7-14f7df39456d

### Overview
AfriKoin Flow is a modern African marketplace mobile application built with React, Vite, TypeScript, and Capacitor for cross-platform mobile deployment.

### Features
- 🏪 African marketplace with classified ads
- 📱 Cross-platform mobile app (Android & iOS)
- 🎵 Web audio/sound application
- 💳 Mobile payment integration ready
- 🎥 Live video streaming capabilities
- 🤖 Voice assistant integration
- 🌍 Localized for African markets

## How can I edit this code?

There are several ways of editing your application.

**Use Lovable**

Simply visit the [Lovable Project](https://lovable.dev/projects/4ba00307-e1d1-4ec3-9df7-14f7df39456d) and start prompting.

Changes made via Lovable will be committed automatically to this repo.

**Use your preferred IDE**

If you want to work locally using your own IDE, you can clone this repo and push changes. Pushed changes will also be reflected in Lovable.

The only requirement is having Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

Follow these steps:

```sh
# Step 1: Clone the repository using the project's Git URL.
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory.
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies.
npm i

# Step 4: Start the development server with auto-reloading and an instant preview.
npm run dev
```

**Edit a file directly in GitHub**

- Navigate to the desired file(s).
- Click the "Edit" button (pencil icon) at the top right of the file view.
- Make your changes and commit the changes.

**Use GitHub Codespaces**

- Navigate to the main page of your repository.
- Click on the "Code" button (green button) near the top right.
- Select the "Codespaces" tab.
- Click on "New codespace" to launch a new Codespace environment.
- Edit files directly within the Codespace and commit and push your changes once you're done.

## Technologies Used

This project is built with:

- **Frontend**: React 18, TypeScript, Vite
- **UI**: shadcn/ui, Tailwind CSS
- **Mobile**: Capacitor (Android & iOS)
- **State Management**: TanStack Query
- **Routing**: React Router
- **Audio**: Web Audio API, MediaRecorder API
- **CI/CD**: GitHub Actions for automated AAB generation

## Mobile Development with Capacitor

### Setup for Mobile Development
```bash
# Initialize Capacitor (already configured)
npx cap init

# Add platforms
npx cap add android
npx cap add ios

# Sync web assets to mobile
npm run build
npx cap sync

# Run on mobile platforms
npx cap run android
npx cap run ios
```

### GitHub Actions - Automated AAB Generation

This project includes automated Android App Bundle (AAB) generation via GitHub Actions.

#### Setup GitHub Secrets for AAB Signing:

1. **KEYSTORE_FILE**: Base64 encoded keystore file
   ```bash
   base64 -i your-keystore.jks | pbcopy
   ```
2. **KEYSTORE_PASSWORD**: Password for the keystore file
3. **KEY_ALIAS**: Alias name in the keystore  
4. **KEY_PASSWORD**: Password for the key alias

#### Workflow Triggers:
- Push to `main` or `master` branch → generates signed release AAB
- Pull requests → generates debug AAB

#### Generated Artifacts:
- Release AAB: `android/app/build/outputs/bundle/release/`
- Debug AAB: `android/app/build/outputs/bundle/debug/`

## How can I deploy this project?

Simply open [Lovable](https://lovable.dev/projects/4ba00307-e1d1-4ec3-9df7-14f7df39456d) and click on Share -> Publish.

## Can I connect a custom domain to my Lovable project?

Yes, you can!

To connect a domain, navigate to Project > Settings > Domains and click Connect Domain.

Read more here: [Setting up a custom domain](https://docs.lovable.dev/tips-tricks/custom-domain#step-by-step-guide)
