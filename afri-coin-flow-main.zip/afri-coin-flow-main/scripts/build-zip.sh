#!/bin/bash

# AfriKoin Flow - Complete Project Archive Generator
# This script creates a complete ZIP archive of the project

echo "🚀 Starting AfriKoin Flow Archive Generation..."

# Set variables
PROJECT_NAME="afrikoin-flow"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
ARCHIVE_NAME="${PROJECT_NAME}_complete_${TIMESTAMP}.zip"
TEMP_DIR="temp_archive"

# Create temporary directory
echo "📁 Creating temporary directory..."
mkdir -p $TEMP_DIR

# Copy essential files
echo "📋 Copying project files..."
cp -r src $TEMP_DIR/
cp -r public $TEMP_DIR/
cp -r android $TEMP_DIR/
cp -r .github $TEMP_DIR/
cp -r scripts $TEMP_DIR/

# Copy configuration files
cp package.json $TEMP_DIR/
cp package-lock.json $TEMP_DIR/
cp capacitor.config.ts $TEMP_DIR/
cp vite.config.ts $TEMP_DIR/
cp tailwind.config.ts $TEMP_DIR/
cp tsconfig.json $TEMP_DIR/
cp tsconfig.app.json $TEMP_DIR/
cp tsconfig.node.json $TEMP_DIR/
cp postcss.config.js $TEMP_DIR/
cp components.json $TEMP_DIR/
cp index.html $TEMP_DIR/
cp README.md $TEMP_DIR/
cp INSTALL.md $TEMP_DIR/

# Copy hidden files
cp .gitignore $TEMP_DIR/
cp eslint.config.js $TEMP_DIR/

# Create the ZIP archive
echo "🗜️ Creating ZIP archive..."
cd $TEMP_DIR
zip -r ../$ARCHIVE_NAME . -x "*.DS_Store" "*/node_modules/*" "*/dist/*" "*/build/*"
cd ..

# Clean up
echo "🧹 Cleaning up..."
rm -rf $TEMP_DIR

# Calculate file size
FILE_SIZE=$(du -h $ARCHIVE_NAME | cut -f1)

echo "✅ Archive created successfully!"
echo "📦 File: $ARCHIVE_NAME"
echo "📏 Size: $FILE_SIZE"
echo ""
echo "🎯 The archive contains:"
echo "   ✓ Complete source code"
echo "   ✓ Android native project"
echo "   ✓ GitHub Actions workflows"
echo "   ✓ All configuration files"
echo "   ✓ Installation instructions"
echo ""
echo "🚀 Ready to deploy to GitHub and generate AAB files!"