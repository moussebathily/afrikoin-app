import { useState } from "react";
import { Heart, MessageCircle, Share, MoreHorizontal, Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/Navigation";

interface Post {
  id: string;
  user: {
    name: string;
    username: string;
    avatar: string;
  };
  content: string;
  media?: {
    type: "image" | "video";
    url: string;
    thumbnail?: string;
  };
  likes: number;
  comments: number;
  shares: number;
  timestamp: string;
  isLiked: boolean;
  hashtags: string[];
}

const mockPosts: Post[] = [
  {
    id: "1",
    user: {
      name: "Koffi Aman",
      username: "@koffi_aman",
      avatar: "/placeholder.svg",
    },
    content: "Nouvelle opportunité d'investissement en Afrikoin! 🚀 Les prix sont en hausse de 15% cette semaine #AfriKoin #Crypto #Investment",
    media: {
      type: "image",
      url: "/placeholder.svg",
    },
    likes: 234,
    comments: 45,
    shares: 12,
    timestamp: "2h",
    isLiked: false,
    hashtags: ["AfriKoin", "Crypto", "Investment"],
  },
  {
    id: "2",
    user: {
      name: "Amina Diallo",
      username: "@amina_trader",
      avatar: "/placeholder.svg",
    },
    content: "Tutoriel rapide sur le trading d'AfriKoin pour débutants 📈",
    media: {
      type: "video",
      url: "/placeholder.svg",
      thumbnail: "/placeholder.svg",
    },
    likes: 567,
    comments: 89,
    shares: 34,
    timestamp: "5h",
    isLiked: true,
    hashtags: ["Trading", "Tutorial", "AfriKoin"],
  },
  {
    id: "3",
    user: {
      name: "Jean-Baptiste",
      username: "@jb_crypto",
      avatar: "/placeholder.svg",
    },
    content: "Les prédictions pour AfriKoin en 2024 sont impressionnantes! Qui d'autre est optimiste? 💪",
    likes: 189,
    comments: 23,
    shares: 8,
    timestamp: "1d",
    isLiked: false,
    hashtags: ["Predictions", "2024", "Bullish"],
  },
];

const Feed = () => {
  const [posts, setPosts] = useState<Post[]>(mockPosts);

  const handleLike = (postId: string) => {
    setPosts(posts.map(post => 
      post.id === postId 
        ? { 
            ...post, 
            isLiked: !post.isLiked, 
            likes: post.isLiked ? post.likes - 1 : post.likes + 1 
          }
        : post
    ));
  };

  const PostCard = ({ post }: { post: Post }) => (
    <Card className="border-0 border-b border-border rounded-none bg-card">
      <CardContent className="p-4">
        {/* Header */}
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={post.user.avatar} />
              <AvatarFallback className="bg-primary/10 text-primary">
                {post.user.name.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div>
              <p className="font-semibold text-foreground">{post.user.name}</p>
              <p className="text-sm text-muted-foreground">{post.user.username} · {post.timestamp}</p>
            </div>
          </div>
          <Button variant="ghost" size="sm">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </div>

        {/* Content */}
        <div className="mb-3">
          <p className="text-foreground leading-relaxed">{post.content}</p>
          <div className="flex flex-wrap gap-1 mt-2">
            {post.hashtags.map((tag) => (
              <Badge key={tag} variant="secondary" className="text-xs">
                #{tag}
              </Badge>
            ))}
          </div>
        </div>

        {/* Media */}
        {post.media && (
          <div className="mb-3 rounded-lg overflow-hidden bg-muted">
            <div className="relative aspect-video">
              <img 
                src={post.media.url} 
                alt="Post media"
                className="w-full h-full object-cover"
              />
              {post.media.type === "video" && (
                <div className="absolute inset-0 flex items-center justify-center">
                  <Button size="lg" className="rounded-full h-16 w-16">
                    <Play className="h-6 w-6" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleLike(post.id)}
              className={`space-x-2 ${post.isLiked ? 'text-red-500' : 'text-muted-foreground'}`}
            >
              <Heart className={`h-5 w-5 ${post.isLiked ? 'fill-current' : ''}`} />
              <span className="text-sm font-medium">{post.likes}</span>
            </Button>
            <Button variant="ghost" size="sm" className="space-x-2 text-muted-foreground">
              <MessageCircle className="h-5 w-5" />
              <span className="text-sm font-medium">{post.comments}</span>
            </Button>
            <Button variant="ghost" size="sm" className="space-x-2 text-muted-foreground">
              <Share className="h-5 w-5" />
              <span className="text-sm font-medium">{post.shares}</span>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60 border-b border-border">
        <div className="container mx-auto px-4 py-3">
          <h1 className="text-xl font-bold text-foreground">Feed Social</h1>
        </div>
      </div>

      {/* Posts Feed */}
      <div className="pb-20">
        {posts.map((post) => (
          <PostCard key={post.id} post={post} />
        ))}
      </div>

      <Navigation />
    </div>
  );
};

export default Feed;