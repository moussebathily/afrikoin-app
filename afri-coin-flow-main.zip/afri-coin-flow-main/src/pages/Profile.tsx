import { useState } from "react";
import { Camera, Edit3, MapPin, Star, ShoppingBag, Heart, Settings, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Navigation from "@/components/Navigation";

const Profile = () => {
  const [activeTab, setActiveTab] = useState("listings");

  const userStats = {
    name: "Amara Okafor",
    username: "@amaraokafor",
    location: "Lagos, Nigeria",
    rating: 4.8,
    reviews: 156,
    joined: "Member since 2022",
    verified: true,
    totalSales: "₦2.5M",
    activeListing: 24,
    completedOrders: 342
  };

  const myListings = [
    {
      id: 1,
      title: "iPhone 13 Pro",
      price: "₦650,000",
      status: "active",
      views: 45,
      image: "/placeholder.svg"
    },
    {
      id: 2,
      title: "MacBook Air M2",
      price: "₦800,000",
      status: "sold",
      views: 78,
      image: "/placeholder.svg"
    },
    {
      id: 3,
      title: "AirPods Pro",
      price: "₦120,000",
      status: "pending",
      views: 23,
      image: "/placeholder.svg"
    }
  ];

  const myOrders = [
    {
      id: 1,
      title: "African Print Fabric",
      seller: "TextileHub Accra",
      price: "₦15,000",
      status: "delivered",
      date: "2024-01-15"
    },
    {
      id: 2,
      title: "Solar Power Bank",
      seller: "EcoTech Kenya",
      price: "$85",
      status: "shipped",
      date: "2024-01-20"
    }
  ];

  const favorites = [
    {
      id: 1,
      title: "Traditional Kente Cloth",
      price: "₦45,000",
      seller: "Ghana Crafts",
      image: "/placeholder.svg"
    },
    {
      id: 2,
      title: "Wireless Headphones",
      price: "$120",
      seller: "TechStore SA",
      image: "/placeholder.svg"
    }
  ];

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Profile Header */}
      <div className="bg-gradient-to-br from-primary to-primary/80 text-white">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col items-center space-y-4">
            <div className="relative">
              <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center">
                <span className="text-3xl font-bold">AO</span>
              </div>
              <Button 
                size="icon" 
                variant="secondary" 
                className="absolute -bottom-2 -right-2 h-8 w-8"
              >
                <Camera className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="text-center">
              <div className="flex items-center justify-center space-x-2 mb-1">
                <h1 className="text-2xl font-bold">{userStats.name}</h1>
                {userStats.verified && (
                  <Badge variant="secondary" className="bg-green-500 text-white">
                    Verified
                  </Badge>
                )}
              </div>
              <p className="text-white/80 mb-2">{userStats.username}</p>
              <div className="flex items-center justify-center space-x-4 text-sm">
                <div className="flex items-center space-x-1">
                  <MapPin className="h-4 w-4" />
                  <span>{userStats.location}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Star className="h-4 w-4 text-yellow-400" />
                  <span>{userStats.rating} ({userStats.reviews} reviews)</span>
                </div>
              </div>
              <p className="text-white/60 text-sm mt-2">{userStats.joined}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="container mx-auto px-4 -mt-8 relative z-10">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{userStats.totalSales}</div>
              <div className="text-sm text-muted-foreground">Total Sales</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{userStats.activeListing}</div>
              <div className="text-sm text-muted-foreground">Active Listings</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-primary">{userStats.completedOrders}</div>
              <div className="text-sm text-muted-foreground">Orders</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="listings">My Listings</TabsTrigger>
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="favorites">Favorites</TabsTrigger>
          </TabsList>

          <TabsContent value="listings">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold">My Listings ({myListings.length})</h3>
                <Button size="sm">
                  <Edit3 className="h-4 w-4 mr-2" />
                  Add Listing
                </Button>
              </div>
              
              {myListings.map((listing) => (
                <Card key={listing.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-4">
                      <img 
                        src={listing.image} 
                        alt={listing.title}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold">{listing.title}</h4>
                        <p className="text-primary font-bold">{listing.price}</p>
                        <p className="text-sm text-muted-foreground">{listing.views} views</p>
                      </div>
                      <Badge 
                        variant={
                          listing.status === "active" ? "default" :
                          listing.status === "sold" ? "secondary" : "outline"
                        }
                      >
                        {listing.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="orders">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">My Orders ({myOrders.length})</h3>
              
              {myOrders.map((order) => (
                <Card key={order.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold">{order.title}</h4>
                        <p className="text-sm text-muted-foreground">from {order.seller}</p>
                        <p className="text-primary font-bold">{order.price}</p>
                      </div>
                      <div className="text-right">
                        <Badge 
                          variant={order.status === "delivered" ? "secondary" : "default"}
                        >
                          {order.status}
                        </Badge>
                        <p className="text-sm text-muted-foreground mt-1">{order.date}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="favorites">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Favorites ({favorites.length})</h3>
              
              {favorites.map((item) => (
                <Card key={item.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-4">
                      <img 
                        src={item.image} 
                        alt={item.title}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold">{item.title}</h4>
                        <p className="text-sm text-muted-foreground">by {item.seller}</p>
                        <p className="text-primary font-bold">{item.price}</p>
                      </div>
                      <Button variant="ghost" size="icon">
                        <Heart className="h-4 w-4 text-red-500 fill-current" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Settings Section */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Account Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full justify-start">
              <Settings className="h-4 w-4 mr-2" />
              Settings & Privacy
            </Button>
            <Button variant="outline" className="w-full justify-start">
              <ShoppingBag className="h-4 w-4 mr-2" />
              Seller Dashboard
            </Button>
            <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700">
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
          </CardContent>
        </Card>
      </div>

      <Navigation />
    </div>
  );
};

export default Profile;