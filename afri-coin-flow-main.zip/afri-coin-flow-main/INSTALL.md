# AfriKoin Flow - Installation & Deployment Guide

This guide will help you set up AfriKoin Flow for AAB generation via GitHub Actions.

## 🚀 Quick Start

### Prerequisites
- Node.js 20+ installed
- Android Studio (for local development)
- GitHub account
- Git installed

### 1. Repository Setup

```bash
# Clone or create your repository
git clone https://github.com/YOUR_USERNAME/afrikoin-app.git
cd afrikoin-app

# Install dependencies
npm install

# Test the web application
npm run dev
```

### 2. Mobile Setup

```bash
# Add Android platform
npm run cap:add:android

# Sync the project
npm run cap:sync

# Test Android build locally (optional)
npm run cap:run:android
```

### 3. GitHub Actions Setup

#### Required GitHub Secrets

For automatic AAB signing, add these secrets to your GitHub repository:

1. Go to your GitHub repository
2. Navigate to Settings > Secrets and variables > Actions
3. Add the following secrets:

| Secret Name | Description | Required |
|-------------|-------------|----------|
| `KEYSTORE_FILE` | Base64 encoded keystore file | Yes (for production) |
| `KEYSTORE_PASSWORD` | Keystore password | Yes (for production) |
| `KEY_ALIAS` | Key alias name | Yes (for production) |
| `KEY_PASSWORD` | Key password | Yes (for production) |

#### Creating a Keystore (Production)

```bash
# Generate a new keystore
keytool -genkey -v -keystore release.keystore -alias afrikoin-key -keyalg RSA -keysize 2048 -validity 10000

# Convert to base64 for GitHub secrets
base64 -i release.keystore | tr -d '\n'
```

### 4. Automated AAB Generation

#### Trigger Options

The GitHub Actions workflow triggers on:
- Push to `main` or `master` branch (Release AAB)
- Pull requests (Debug AAB)
- Manual dispatch via GitHub Actions tab

#### Build Process

1. **Automatic**: Push code to main branch
```bash
git add .
git commit -m "Deploy AfriKoin Flow"
git push origin main
```

2. **Manual**: Go to GitHub Actions tab and click "Run workflow"

#### Download AAB

1. Go to GitHub Actions tab
2. Click on the latest workflow run
3. Download the AAB artifact
4. Extract and upload to Google Play Console

## 📱 Project Structure

```
afrikoin-app/
├── src/                    # React source code
│   ├── components/         # Reusable components
│   ├── pages/             # Application pages
│   └── assets/            # Static assets
├── android/               # Native Android project
│   ├── app/               # Android app module
│   └── build.gradle       # Android build configuration
├── .github/workflows/     # GitHub Actions workflows
├── scripts/               # Build scripts
├── capacitor.config.ts    # Capacitor configuration
└── package.json          # Node.js dependencies
```

## 🔧 Configuration Files

### Key Configuration Files

1. **capacitor.config.ts**: Mobile app configuration
2. **android/app/build.gradle**: Android build settings
3. **.github/workflows/android-build.yml**: CI/CD pipeline
4. **package.json**: Build scripts and dependencies

### Environment Variables

The project uses these environment variables in GitHub Actions:

- `NODE_VERSION`: Node.js version (20)
- `JAVA_VERSION`: Java version (17)
- `KEYSTORE_PASSWORD`: Production keystore password
- `KEY_ALIAS`: Production key alias
- `KEY_PASSWORD`: Production key password

## 🛠️ Development Commands

### Web Development
```bash
npm run dev          # Start development server
npm run build        # Build web assets
npm run preview      # Preview built web app
npm run lint         # Run ESLint
```

### Mobile Development
```bash
npm run cap:sync               # Sync web assets to native
npm run cap:run:android        # Run on Android device/emulator
npm run cap:build:android      # Build Android APK
npm run cap:bundle:android     # Build Android AAB
npm run android:clean          # Clean Android build cache
```

### Automation
```bash
npm run mobile:setup     # Complete mobile setup
npm run build:zip        # Create deployment archive
```

## 🐛 Troubleshooting

### Common Issues

1. **Gradle Build Fails**
   - Check Java version (requires JDK 17)
   - Run `npm run android:clean`
   - Verify Android SDK installation

2. **Capacitor Sync Issues**
   - Run `npm run build` first
   - Check capacitor.config.ts settings
   - Verify web assets in dist/ folder

3. **GitHub Actions Fails**
   - Check GitHub secrets are set correctly
   - Verify keystore file is valid base64
   - Check workflow logs for specific errors

4. **AAB Signing Issues**
   - Verify keystore passwords in GitHub secrets
   - Check key alias matches
   - Ensure keystore file is correctly base64 encoded

### Debug Mode

For testing without production keystore:
- The workflow automatically generates debug keystores
- Debug AABs are created for non-main branches
- Debug builds don't require GitHub secrets

## 🚀 Deployment Checklist

- [ ] Repository created and code uploaded
- [ ] GitHub secrets configured (for production)
- [ ] Android platform added via Capacitor
- [ ] First successful GitHub Actions run
- [ ] AAB file downloaded and tested
- [ ] Google Play Console configured

## 📞 Support

For issues or questions:
1. Check the troubleshooting section above
2. Review GitHub Actions logs
3. Verify all configuration files
4. Ensure all dependencies are installed

## 🎯 Next Steps

After successful setup:
1. Customize the app branding and content
2. Configure Google Play Console
3. Set up app signing in Play Console
4. Upload your first AAB for testing
5. Plan your production release

---

**Happy Coding! 🎉**

Your AfriKoin Flow app is now ready for automatic AAB generation and deployment.