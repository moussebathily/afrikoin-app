import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.4ba00307e1d14ec39df714f7df39456d',
  appName: 'afri-coin-flow',
  webDir: 'dist',
  server: {
    url: 'https://4ba00307-e1d1-4ec3-9df7-14f7df39456d.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  android: {
    buildOptions: {
      keystorePath: undefined,
      keystorePassword: undefined,
      keystoreAlias: undefined,
      keystoreAliasPassword: undefined,
      releaseType: 'AAB'
    }
  }
};

export default config;