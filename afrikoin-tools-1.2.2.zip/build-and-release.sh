#!/bin/bash

VERSION="1.2.2"

echo "📦 Compilation AfriKoin v$VERSION (AAB)..."

if ! command -v eas &> /dev/null
then
    echo "❌ eas-cli n'est pas installé. Lancer : npm install -g eas-cli"
    exit 1
fi

APP_VERSION=$VERSION eas build --platform android --profile production --non-interactive

if [ $? -ne 0 ]; then
    echo "❌ Build échoué"
    exit 1
fi

echo "🏷 Création du tag Git v$VERSION..."
git tag -a "v$VERSION" -m "Release v$VERSION"
git push origin "v$VERSION"

echo "✅ Build & tag complétés avec succès pour AfriKoin v$VERSION"
