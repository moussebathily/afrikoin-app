#!/bin/bash

VERSION="1.2.2"
git log $(git describe --tags --abbrev=0)..HEAD --pretty=format:"* %s" > CHANGELOG.md

echo "📝 Changelog généré pour la version $VERSION :"
cat CHANGELOG.md
